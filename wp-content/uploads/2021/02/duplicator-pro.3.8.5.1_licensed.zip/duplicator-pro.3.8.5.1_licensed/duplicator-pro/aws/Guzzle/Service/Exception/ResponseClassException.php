<?php
namespace DuplicatorPro\Guzzle\Service\Exception;

use DuplicatorPro\Guzzle\Common\Exception\RuntimeException;

class ResponseClassException extends RuntimeException
{
}
